function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6a3xQkvLXzQ":
        Script1();
        break;
      case "5dX5uf8jv6L":
        Script2();
        break;
      case "6pJBmHUyU98":
        Script3();
        break;
  }
}

function Script1()
{
  function add_script(scriptURL,oID) {
var scriptEl = document.createElement("script");
var head=document.getElementsByTagName('head')[0];
scriptEl.type = "text/javascript"; 
scriptEl.src = scriptURL; 
scriptEl.id=oID; 
head.appendChild(scriptEl);}

//only want to add these once! you need jquery, currently hooked up 
//to version 1.11.2

if(document.getElementById('jquery')==null){
add_script("https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js","jquery");
}
}

function Script2()
{
  // google URL Adaptive leadership usage script

// store the clicking
var player = GetPlayer();
player.SetVar("answer","2");  
player.SetVar("AnswerOfferHelp","1"); 

// makes the call to post to google doc for more information on the setup, refer to
// https://community.articulate.com/discussions/articulate-storyline/exporting-variables-into-a-google-spreadsheet

$.ajax({

url: 
"https://script.google.com/macros/s/AKfycbzjJSSunklqtWtw5bYy42C32JdPGHtFTu8svyqI-XA40c6QtIQ/exec",

type: "POST",
data: { "AnswerSupervisor" : player.GetVar("AnswerSupervisor"), "AnswerOfferHelp": player.GetVar("AnswerOfferHelp")},

success: function(data)
{
}, 

error: function(err) {
console.log(err);
}

});

return false;

}

function Script3()
{
  // google URL Adaptive leadership usage script

var player = GetPlayer();

player.SetVar("answer","1");
player.SetVar("AnswerSupervisor","1"); 

$.ajax({

url: 
"https://script.google.com/macros/s/AKfycbzjJSSunklqtWtw5bYy42C32JdPGHtFTu8svyqI-XA40c6QtIQ/exec",

type: "POST",
data: { "AnswerSupervisor" : player.GetVar("AnswerSupervisor"), "AnswerOfferHelp": player.GetVar("AnswerOfferHelp")},

success: function(data)
{
}, 

error: function(err) {
console.log(err);
}

});

return false;

}

